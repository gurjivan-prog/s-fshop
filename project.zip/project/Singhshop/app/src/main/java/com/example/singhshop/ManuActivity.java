package com.example.singhshop;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.TextureView;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class ManuActivity extends AppCompatActivity {
    private Button Back;
    private Button NEXT;
    private TextView item_1_quantity,item_2_quantity,item_3_quantity,item_4_quantity;
    int count1,count2,count3,count4;
    private Button item_1_increase,item_1_decrease;
    private Button item_2_increase,item_2_decrease;
    private Button item_3_increase,item_3_decrease;
    private Button item_4_increase,item_4_decrease;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manu);
        item_1_increase= findViewById(R.id. item_1_increase);item_1_decrease= findViewById(R.id. item_1_decrease);
        item_2_increase= findViewById(R.id. item_2_increase);item_2_decrease= findViewById(R.id. item_2_decrease);
        item_3_increase= findViewById(R.id. item_3_increase);item_3_decrease= findViewById(R.id. item_3_decrease);
        item_4_increase= findViewById(R.id. item_4_increase);item_4_decrease= findViewById(R.id. item_4_decrease);
        item_1_quantity=findViewById(R.id. item_1_quantity); item_2_quantity=findViewById(R.id. item_2_quantity);
        item_3_quantity=findViewById(R.id. item_3_quantity); item_4_quantity=findViewById(R.id. item_4_quantity);

        item_1_increase.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                count1++;
                item_1_quantity.setText(count1);
            }
        });
        item_1_decrease.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                count1--;
                item_1_quantity.setText(count1);
            }
        });
//for item 2
        item_2_increase.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                count2++;
                item_2_quantity.setText(count2);
            }
        });
        item_2_decrease.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                count2--;
                item_2_quantity.setText(count2);
            }
        });
//for item 3
        item_3_increase.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                count3++;
                item_3_quantity.setText(count3);
            }
        });
        item_3_decrease.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                count3--;
                item_3_quantity.setText(count3);
            }
        });
//for item 4
        item_4_increase.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                count4++;
                item_4_quantity.setText(count4);
            }
        });
        item_4_decrease.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                count4--;
                item_4_quantity.setText(count4);
            }
        });




        Back=(Button) findViewById(R.id.Back);
        Back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openMainActivity();

            }
        });
        NEXT=(Button) findViewById(R.id.next);
        NEXT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openCheckoutActivity();

            }
        });
    }
    public void openMainActivity(){
        Intent intent= new Intent(this,MainActivity.class);
        startActivity(intent);
    }
    public void openCheckoutActivity(){
        Intent intent2= new Intent(this,CheckoutActivity.class);
        startActivity(intent2);
    }
}
