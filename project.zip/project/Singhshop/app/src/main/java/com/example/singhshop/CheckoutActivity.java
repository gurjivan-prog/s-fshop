package com.example.singhshop;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import javax.xml.transform.Result;

public class CheckoutActivity extends AppCompatActivity {
    private Button calculate;
    private EditText num1;
    private EditText result1;
    private EditText num2;
    private EditText result2;
    private EditText num3;
    private EditText result3;
    private EditText num4;
    private EditText result4;
    private EditText subtotal;
    private EditText total;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checkout);
        calculate=findViewById(R.id.Calculate);
        num1 =findViewById(R.id.quantity_1);
        result1 =findViewById(R.id.price_1);
        num2 =findViewById(R.id.quantity_2);
        result2 =findViewById(R.id.price_2);
        num3 =findViewById(R.id.quantity_3);
        result3 =findViewById(R.id.price_3);
        num4 =findViewById(R.id.quantity_4);
        result4 =findViewById(R.id.price_4);
        subtotal=findViewById(R.id.subtotal1);
        total=findViewById(R.id.total1);

        calculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double a,b,c,d,e,f,g,h,i,j;
                a=Double.parseDouble(num1.getText().toString());
                b= a*(7);
                c=Double.parseDouble(num2.getText().toString());
                d= a*(5);
                e=Double.parseDouble(num3.getText().toString());
                f= a*(4);
                g=Double.parseDouble(num4.getText().toString());
                h= a*(6);
                i=b+d+f+h;
                j=((0.15*i)+i);
                result1.setText(Double.toString(b));
                result2.setText(Double.toString(d));
                result3.setText(Double.toString(f));
                result4.setText(Double.toString(h));
                subtotal.setText(Double.toString(i));
                total.setText(Double.toString(j));


            }
        });
    }
}
